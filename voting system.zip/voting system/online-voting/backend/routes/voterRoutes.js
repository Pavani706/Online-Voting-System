const express = require('express');
const router = express.Router();
const Voter = require('../models/Voter');

router.post('/register', async (req, res) => {
    try {
        const { name, rollNumber, email, password } = req.body;
        const newVoter = new Voter({ name, rollNumber, email, password });
        await newVoter.save();
        res.status(201).json({ message: "Voter registered successfully!" });
    } catch (err) {
        res.status(500).json({ error: "Registration failed" });
    }
});

module.exports = router;