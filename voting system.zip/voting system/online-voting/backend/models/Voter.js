const mongoose = require('mongoose');

const voterSchema = new mongoose.Schema({
    name: String,
    rollNumber: String,
    email: String,
    password: String
});

module.exports = mongoose.model('Voter', voterSchema);