let registeredVoters = [];
let votes = { "Pavani": 0, "Reehana": 0, "Christy": 0 };

document.getElementById('registrationForm').addEventListener('submit', function (event) {
  event.preventDefault();
  const username = document.getElementById('username').value.trim();
  if (username) {
    registeredVoters.push(username);
    alert(`Registration successful for: ${username}`);
    document.getElementById('register').style.display = 'none';
    document.getElementById('vote').style.display = 'block';
  }
});

document.getElementById('voteForm').addEventListener('submit', function (event) {
  event.preventDefault();
  const selectedCandidate = document.querySelector('input[name="candidate"]:checked')?.value;
  if (selectedCandidate) {
    votes[selectedCandidate]++;
    alert(`${selectedCandidate} has received a vote!`);

    // Display the results after voting
    document.getElementById('vote').style.display = 'none';
    document.getElementById('results').style.display = 'block';
    document.getElementById('resultsPavani').textContent = `Pavani: ${votes["Pavani"]} votes`;
    document.getElementById('resultsReehana').textContent = `Reehana: ${votes["Reehana"]} votes`;
    document.getElementById('resultsChristy').textContent = `Christy: ${votes["Christy"]} votes`;
  } else {
    alert("Please select a candidate to vote!");
  }
});
